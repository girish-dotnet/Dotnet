SELECT
	SERVERPROPERTY('Edition') AS Edition,
	SERVERPROPERTY('ProductLevel') AS ProductLevel,
	SERVERPROPERTY('ProductVersion') AS ProductVersion

